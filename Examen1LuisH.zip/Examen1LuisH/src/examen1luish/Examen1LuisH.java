/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examen1luish;

import javax.swing.JOptionPane;

/**
 *
 * @author Aulas Heredia
 */
public class Examen1LuisH {

    public static void main(String[] args) {

        //Vendedor//
        Vendedor vendedor1 = new Vendedor();
        vendedor1.nombre = JOptionPane.showInputDialog("Ingrese su nombre");
        vendedor1.vehiculopropio = JOptionPane.showInputDialog("Ingrese su nombre");
        vendedor1.sucursal = JOptionPane.showInputDialog("Ingrese su nombre");
        vendedor1.codigo = JOptionPane.showInputDialog("Ingrese su codigo");
        vendedor1.id = JOptionPane.showInputDialog("Ingrese su cedula");

        //Facturas//
        Cliente cliente1 = new Cliente();
        cliente1.nombre = "Julio Sanchez";
        cliente1.cedula = 11202000;
        cliente1.factura = 2351;
        cliente1.monto = 20000;
        cliente1.mes = 1;
        cliente1.productosautomotrices = 0;
        cliente1.productoselectricos = 0;
        cliente1.productosconstruccion = 6;

        System.out.println("El nombre del cliente es: " + cliente1.nombre);
        System.out.println("La cedula del cliente es: " + cliente1.cedula);
        System.out.println("El codigo de la factura del cliente es: " + cliente1.factura);
        System.out.println("El monto de la factura del cliente es: " + cliente1.monto);
        System.out.println("El mes en el que se facturo es: " + cliente1.mes);
        System.out.println("¿La factura contiene productos automotrices?: " + cliente1.productosautomotrices);
        System.out.println("¿La factura contiene productos construccion?" + cliente1.productosconstruccion);
        System.out.println("¿La factura contiene productos electricos?" + cliente1.productoselectricos);

        Cliente cliente2 = new Cliente();
        cliente2.nombre = "Ramon Sanchez";
        cliente2.cedula = 11202001;
        cliente2.factura = 2546;
        cliente2.monto = 35000;
        cliente2.mes = 2;
        cliente2.productosautomotrices = 0;
        cliente2.productoselectricos = 3;
        cliente2.productosconstruccion = 0;

        System.out.println("El nombre del cliente es: " + cliente2.nombre);
        System.out.println("La cedula del cliente es: " + cliente2.cedula);
        System.out.println("El codigo de la factura del cliente es: " + cliente2.factura);
        System.out.println("El monto de la factura del cliente es: " + cliente2.monto);
        System.out.println("El mes en el que se facturo es: " + cliente2.mes);
        System.out.println("¿La factura contiene productos automotrices?: " + cliente2.productosautomotrices);
        System.out.println("¿La factura contiene productos construccion?" + cliente2.productosconstruccion);
        System.out.println("¿La factura contiene productos electricos?" + cliente2.productoselectricos);

        Cliente cliente3 = new Cliente();
        cliente3.nombre = "Julio Valdez";
        cliente3.cedula = 11202002;
        cliente3.factura = 2700;
        cliente3.monto = 60000;
        cliente3.mes = 3;
        cliente3.productosautomotrices = 2;
        cliente3.productoselectricos = 0;
        cliente3.productosconstruccion = 0;

        System.out.println("El nombre del cliente es: " + cliente3.nombre);
        System.out.println("La cedula del cliente es: " + cliente3.cedula);
        System.out.println("El codigo de la factura del cliente es: " + cliente3.factura);
        System.out.println("El monto de la factura del cliente es: " + cliente3.monto);
        System.out.println("El mes en el que se facturo es: " + cliente3.mes);
        System.out.println("¿La factura contiene productos automotrices?: " + cliente3.productosautomotrices);
        System.out.println("¿La factura contiene productos construccion?" + cliente3.productosconstruccion);
        System.out.println("¿La factura contiene productos electricos?" + cliente3.productoselectricos);

        Cliente cliente4 = new Cliente();
        cliente4.nombre = "Natalia Monge";
        cliente4.cedula = 11202003;
        cliente4.factura = 2351;
        cliente4.monto = 25000;
        cliente4.mes = 4;
        cliente4.productosautomotrices = 2;
        cliente4.productoselectricos = 2;
        cliente4.productosconstruccion = 1;

        System.out.println("El nombre del cliente es: " + cliente4.nombre);
        System.out.println("La cedula del cliente es: " + cliente4.cedula);
        System.out.println("El codigo de la factura del cliente es: " + cliente4.factura);
        System.out.println("El monto de la factura del cliente es: " + cliente4.monto);
        System.out.println("El mes en el que se facturo es: " + cliente4.mes);
        System.out.println("¿La factura contiene productos automotrices?: " + cliente4.productosautomotrices);
        System.out.println("¿La factura contiene productos construccion?" + cliente4.productosconstruccion);
        System.out.println("¿La factura contiene productos electricos?" + cliente4.productoselectricos);

        Cliente cliente5 = new Cliente();
        cliente5.nombre = "Jimena Pereira";
        cliente5.cedula = 11202004;
        cliente5.factura = 2912;
        cliente5.monto = 45000;
        cliente5.mes = 5;
        cliente5.productosautomotrices = 2;
        cliente5.productoselectricos = 1;
        cliente5.productosconstruccion = 0;
        

        System.out.println("El nombre del cliente es: " + cliente5.nombre);
        System.out.println("La cedula del cliente es: " + cliente5.cedula);
        System.out.println("El codigo de la factura del cliente es: " + cliente5.factura);
        System.out.println("El monto de la factura del cliente es: " + cliente5.monto);
        System.out.println("El mes en el que se facturo es: " + cliente5.mes);
        System.out.println("¿La factura contiene productos automotrices?: " + cliente5.productosautomotrices);
        System.out.println("¿La factura contiene productos construccion?" + cliente5.productosconstruccion);
        System.out.println("¿La factura contiene productos electricos?" + cliente5.productoselectricos);

        //Calificacion de comisiones y puntos de vendedor//
        
        
        
        
        
        
        
    }
        
                
        //System.out.println("El nombre del vendedor es: " + vendedor1.nombre);
        //System.out.println("¿Tiene vehiculo propio?: " + vendedor1.vehiculopropio);
        //System.out.println("¿Cual es su sucursal?" + vendedor1.sucursal);
       // System.out.println("Su codigo es:" + vendedor1.codigo);
        //System.out.println("Puntos obtenidos: " + vendedor1.id);
        //System.out.println("¿El agente vendedor logro llegar al bono extra?" + vendedor1.id);
        //System.out.println("Obtuvo un total de comisiones: " + vendedor1.id);

    }


