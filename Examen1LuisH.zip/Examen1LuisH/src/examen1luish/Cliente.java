/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen1luish;

/**
 *
 * @author Aulas Heredia
 */
public class Cliente {

    public String nombre;
    public int cedula;
    public int factura;
    public int monto;
    public int mes;
    public int productoselectricos;
    public int productosautomotrices;
    public int productosconstruccion;

 
      
             
      
        
    }


